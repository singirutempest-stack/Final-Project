INSERT INTO roles (name) VALUES
('ADMIN'),
('USER'),
('SELLER');
