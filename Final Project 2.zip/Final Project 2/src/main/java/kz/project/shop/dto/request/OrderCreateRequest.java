package kz.project.shop.dto.request;

public class OrderCreateRequest {
    private Long userId;
}
