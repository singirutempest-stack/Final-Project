INSERT INTO users (email, password, blocked) VALUES

('Dias_professor@marketplace.kz', '$2a$10$3rN2kGZ9L8q2n2ZbJ9jG4eE9qQeO5g9U6Rk1zq5pQ5W6nq2s9kY5a', FALSE),


('messi@marketplace.kz', '$2a$10$3rN2kGZ9L8q2n2ZbJ9jG4eE9qQeO5g9U6Rk1zq5pQ5W6nq2s9kY5a', FALSE),
('ronaldo@marketplace.kz', '$2a$10$3rN2kGZ9L8q2n2ZbJ9jG4eE9qQeO5g9U6Rk1zq5pQ5W6nq2s9kY5a', FALSE),

-- USERS
('akim@marketplace.kz', '$2a$10$3rN2kGZ9L8q2n2ZbJ9jG4eE9qQeO5g9U6Rk1zq5pQ5W6nq2s9kY5a', FALSE),
('daulet@marketplace.kz', '$2a$10$3rN2kGZ9L8q2n2ZbJ9jG4eE9qQeO5g9U6Rk1zq5pQ5W6nq2s9kY5a', FALSE),
('karim@marketplace.kz', '$2a$10$3rN2kGZ9L8q2n2ZbJ9jG4eE9qQeO5g9U6Rk1zq5pQ5W6nq2s9kY5a', FALSE),
('ernar@marketplace.kz', '$2a$10$3rN2kGZ9L8q2n2ZbJ9jG4eE9qQeO5g9U6Rk1zq5pQ5W6nq2s9kY5a', FALSE);
